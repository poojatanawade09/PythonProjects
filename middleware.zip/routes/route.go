package routes

import (
	"panvalidation/handlers"

	"github.com/gin-gonic/gin"
)

// SetupRouter initializes the router and routes
func SetupRouter(router *gin.Engine, handler *handlers.RequestHandler) {

	router.POST("/submit", handler.HandlePostRequest)
}
