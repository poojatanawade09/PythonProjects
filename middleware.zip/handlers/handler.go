package handlers

import (
	"net/http"
	"panvalidation/models"
	"panvalidation/services"

	"github.com/gin-gonic/gin"
)

type RequestHandler struct {
	validationService *services.ValidationService
}

func NewRequestHandler(vs *services.ValidationService) *RequestHandler {
	return &RequestHandler{validationService: vs}
}
func (rh *RequestHandler) HandlePostRequest(c *gin.Context) {
	var payload models.RequestPayload
	if err := c.ShouldBindJSON(&payload); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid Data"})
		return
	}
	if err := rh.validationService.ValidateStruct(payload); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid Data"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Success-Data Processed"})
}
