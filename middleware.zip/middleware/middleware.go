package middleware

import (
	"log"
	"time"

	"github.com/gin-gonic/gin"
)

// LatencyLogger logs the latency of each request
func LatencyLogger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		latency := time.Since(start)
		log.Printf("Request processed in %v\n", latency)
	}
}
