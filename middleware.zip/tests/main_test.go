package tests

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"panvalidation/handlers"
	"panvalidation/services"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestHandlePostRequest(t *testing.T) {
	// Initialize Gin in test mode
	gin.SetMode(gin.TestMode)
	// Initialize the validation service and request handler
	validationService := services.NewValidationService()
	handler := handlers.NewRequestHandler(validationService)
	// Create a Gin router and register the handler
	router := gin.Default()
	router.POST("/submit", handler.HandlePostRequest)
	// Define test cases
	tests := []struct {
		name           string
		payload        string
		expectedStatus int
		expectedBody   string
	}{
		{name: "Valid Request",
			payload:        `{"name": "John Doe", "pan": "ABCDE1234F", "mobile": "9876543210", "email": "john@example.com"}`,
			expectedStatus: http.StatusOK,
			expectedBody:   `{"message":"Success-Data Processed"}`,
		},
		{name: "Invalid PAN Format",
			payload:        `{"name": "John Doe", "pan": "1234ABCDE", "mobile": "9876543210", "email": "john@example.com"}`,
			expectedStatus: http.StatusBadRequest,
			expectedBody:   `{"error":"Invalid Data"}`},
		{name: "Invalid Mobile Number",
			payload:        `{"name": "John Doe", "pan": "ABCDE1234F", "mobile": "123456", "email": "john@example.com"}`,
			expectedStatus: http.StatusBadRequest,
			expectedBody:   `{"error":"Invalid Data"}`},
		{name: "Missing Required Fields",
			payload:        `{}`,
			expectedStatus: http.StatusBadRequest,
			expectedBody:   `{"error":"Invalid Data"}`},
		{name: "Invalid Email Format",
			payload:        `{"name": "John Doe", "pan": "ABCDE1234F", "mobile": "9876543210", "email": "johnexample.com"}`,
			expectedStatus: http.StatusBadRequest,
			expectedBody:   `{"error":"Invalid Data"}`}}
	// Run the test cases
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := http.NewRequest(http.MethodPost, "/submit", bytes.NewBuffer([]byte(tt.payload)))
			req.Header.Set("Content-Type", "application/json")
			// Create a response recorder
			respRecorder := httptest.NewRecorder()
			// Serve the request
			router.ServeHTTP(respRecorder, req)
			// Validate status code
			assert.Equal(t, tt.expectedStatus, respRecorder.Code)
			// Validate response body (partial match)
			assert.Contains(t, respRecorder.Body.String(), tt.expectedBody)
		})
	}
}
