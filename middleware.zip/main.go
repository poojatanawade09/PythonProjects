package main

import (
	"log"

	"panvalidation/handlers"
	"panvalidation/middleware"
	"panvalidation/routes"
	"panvalidation/services"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	r.Use(middleware.LatencyLogger()) // Register middleware

	validationService := services.NewValidationService()
	requestHandler := handlers.NewRequestHandler(validationService)
	routes.SetupRouter(r, requestHandler)
	log.Println("Server running on port 8080...")
	r.Run(":8080")
}
