package models

// RequestPayload defines the structure of incoming JSON request
type RequestPayload struct {
	Name   string `json:"name" binding:"required"`
	PAN    string `json:"pan" binding:"required" validate:"pan"`
	Mobile string `json:"mobile" binding:"required" validate:"mobile"`
	Email  string `json:"email" binding:"required,email"`
}
