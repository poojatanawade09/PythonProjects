package services

import (
	"regexp"

	"github.com/go-playground/validator/v10"
)

// ValidationService provides methods for validating input data
type ValidationService struct {
	validator *validator.Validate
}

// NewValidationService initializes a new validation service
func NewValidationService() *ValidationService {
	v := validator.New()
	v.RegisterValidation("pan", validatePAN)
	v.RegisterValidation("mobile", validateMobile)
	return &ValidationService{validator: v}
}

// ValidateStruct validates a given struct
func (vs *ValidationService) ValidateStruct(i interface{}) error {
	return vs.validator.Struct(i)
}

// validatePAN checks if PAN follows the format ABCDE1234F
func validatePAN(fl validator.FieldLevel) bool {
	pan := fl.Field().String()
	regex := regexp.MustCompile(`^[A-Z]{5}[0-9]{4}[A-Z]{1}$`)
	return regex.MatchString(pan)
}

// validateMobile ensures mobile number is 10 digits
func validateMobile(fl validator.FieldLevel) bool {
	mobile := fl.Field().String()
	regex := regexp.MustCompile(`^[6-9]\d{9}$`)
	return regex.MatchString(mobile)
}
